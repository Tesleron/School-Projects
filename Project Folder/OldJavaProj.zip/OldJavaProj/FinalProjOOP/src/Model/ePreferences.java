package Model;

public enum ePreferences {
	LATER,EARLIER,SAME,HOME;
}
