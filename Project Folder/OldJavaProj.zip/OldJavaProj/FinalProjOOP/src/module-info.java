module FinalProjOOP {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
	requires java.desktop;
	
	opens Model to javafx.graphics, javafx.fxml;
}
