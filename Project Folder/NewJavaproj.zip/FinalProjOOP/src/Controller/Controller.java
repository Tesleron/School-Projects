package Controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

//import javax.swing.JOptionPane;

import Model.Model;
import View.View;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Spinner;
import javafx.stage.StageStyle;

public class Controller {
	private Model theModel;
	private View theView;

	public Controller(Model model, View view) throws SQLException {
		theModel = model;
		theView = view;

		// EVENT HANDLERS

		try {
			theModel.loadCompany();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		EventHandler<ActionEvent> addAnotherEmpButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				view.getInsertEntStage().setScene(view.getEmpScene());
			}

		};

		EventHandler<ActionEvent> addNewRoleButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				view.getInsertEntStage().setScene(view.getRoleScene());
			}

		};

		EventHandler<ActionEvent> addNewDepButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				view.getInsertEntStage().setScene(view.getDepScene());

			}

		};

		EventHandler<ActionEvent> finishButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {

				try {
					//theModel.saveToFile();
					theModel.createCompany(theModel.getCompany().getCompanyName());
					theModel.getDB().setCompanyData(theModel.getCompany());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				view.getInsertEntStage().close();// return to main menu
			}
		};

		EventHandler<ActionEvent> submitEmployeeButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				try {
					sendEmployeeData(view.getSelectedButton().getText().toUpperCase(), /* view.getIsChangeable(), */
							view.getSelectedButton().getText().toUpperCase().equals("LATER") ? view.getLaterHourDelta()
									: view.getEarlyHourDelta(),
							view.getSelectedEmployeeType().getText().toUpperCase(), view.getBaseSalary().getValue(),
							view.getSalesLastMonth().getValue(), view.getPerHour().getValue());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				view.afterSubmitEmpWindow();
				view.addEventToAfterSubmitButtons(addAnotherEmpButtonEvent, addNewRoleButtonEvent, addNewDepButtonEvent,
						finishButtonEvent);

			}

		};

		EventHandler<ActionEvent> addEmployeeButtonEvent = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				try {
					sendRoleData(view.getSelectedRoleButton().getText().toUpperCase(), view.getRoleIsChangeable(),
							view.getRoleIsSynchronized(),
							view.getSelectedRoleButton().getText().toUpperCase().equals("LATER")
									? view.getRoleLaterHourDelta()
									: view.getRoleEarlyHourDelta());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				view.addEmployeeWindow();
				view.addEventToSubmitEmployee(submitEmployeeButtonEvent);

			}

		};
		EventHandler<ActionEvent> addRoleButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				try {
					sendDepartmentData(view.getSelectedDepButton().getText().toUpperCase(), view.getDepIsChangeable(),
							view.getDepIsSynchronized(),
							view.getSelectedDepButton().getText().toUpperCase().equals("LATER")
									? view.getDepLaterHourDelta()
									: view.getDepEarlyHourDelta());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				view.addRoleWindow();
				view.addEventToAddEmployee(addEmployeeButtonEvent);
			}

		};

		EventHandler<ActionEvent> addDepartmentButtonEvent = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				sendCompanyData(view.getCompanyNametf());
				view.addDepartmentWindow(theModel.getCompany());
				view.addEventToAddRole(addRoleButtonEvent);
			}

		};

		EventHandler<ActionEvent> InsertEntitiesHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
//				if (theModel.getCompany() != null) {
//					if (view.askBeforeInsertion())
//						view.addEventToAddDepartment(addDepartmentButtonEvent);
//				} else {
//					view.InsertEntitiesPopup();
//					view.addEventToAddDepartment(addDepartmentButtonEvent);
//				}
				if(theModel.getCompany().getAllDepartments().size() > 0) {
				//	Stage stg = view.getInsertEntStage();
					view.addDepartmentWindow(theModel.getCompany());
					view.addEventToAddRole(addRoleButtonEvent);
				}
				else {
					view.InsertEntitiesPopup();
					view.addEventToAddDepartment(addDepartmentButtonEvent);
				}
			}

		};
		view.addEventToInsertEntities(InsertEntitiesHandler);

		EventHandler<ActionEvent> showEntitiesHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {

				if (theModel.getCompany() != null)
					view.showEntitiesPopup(theModel.getCompany());
				else {
					view.alertCompanyNull("show entites.");
				}

			}

		};
		view.addEventToShowEntities(showEntitiesHandler);

		EventHandler<ActionEvent> editButtonHandlerDep = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				try {
					updateDepData(view.getDepIndexToChange(), view.getSelectedDepButton().getText().toUpperCase(),
							view.getDepIsChangeable(), view.getDepIsSynchronized(),
							view.getSelectedDepButton().getText().toUpperCase().equals("LATER")
									? view.getDepLaterHourDelta()
									: view.getDepEarlyHourDelta());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					theModel.saveToFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		};

		EventHandler<ActionEvent> editButtonHandlerRole = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				try {
					updateRoleData(view.getDepIndexToChange(), view.getSelectedRoleButton().getText().toUpperCase(),
							view.getRoleIsChangeable(), view.getRoleIsSynchronized(),
							view.getSelectedRoleButton().getText().toUpperCase().equals("LATER")
									? view.getRoleLaterHourDelta()
									: view.getRoleEarlyHourDelta(),
							view.getRoleIndexToChange());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					theModel.saveToFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		};

		EventHandler<ActionEvent> nextStepDepPrefHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
//				System.out.println("Clicked on next step");
				view.prefEditorWindow(view.getSelectedDepButton().getText());
				view.addEventToEditButton(editButtonHandlerDep);

			}

		};

		EventHandler<ActionEvent> nextStepRolePrefHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
//				System.out.println("Clicked on next step");
				view.prefRoleEditorWindow(view.getSelectedRoleButton().getText());
				view.addEventToEditRoleButton(editButtonHandlerRole);

			}

		};
		
		EventHandler<ActionEvent> removeNowButtonHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				String query;
				
				String whatToDelete = theView.getSelectedDeleteButton().getText();
				String arr[] = whatToDelete.split(" ", 2);
				String firstWord = arr[0];   //department or role or whatever
				char id = whatToDelete.charAt(whatToDelete.length() - 1);
				
				//System.out.println(firstWord +"," + id);
				
				if(firstWord.equals("Department")) {
					//theModel.getCompany().getAllDepartments().remove(id - 1);
					//depSerial -=1;
					
				//	theModel.getCompany().getAllDepartments().get(0).minusDepSerial();
					query = "DELETE FROM "+firstWord+"table WHERE DepID = "+id+";";
				}
				else if(firstWord.equals("Role")) {
					//int index = theModel.findRoleByID(theModel.getCompany().getAllDepartments());
					//theModel.getCompany().getAllDepartments().get(0).getRoles().get(0).minusRoleSerial();
					query = "DELETE FROM "+firstWord+"table WHERE RoleID = "+id+";";

				}
				else {
					//theModel.getCompany().getAllDepartments().get(0).getRoles().get(0).getEmployees().get(0).minusEmpSerial();
					query = "DELETE FROM employeetable WHERE EmpID = "+id+";";
				}
				
				try {
					theModel.getDB().updateByQuery(query);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				theModel.createCompany(theModel.getCompany().getCompanyName());
				try {
					if(theModel.getCompany().getAllDepartments().size() == 0) {
//						String alterIncrementQuery = "ALTER TABLE departmenttable auto_increment = 1;\n"
//								+ "ALTER TABLE employeetable auto_increment = 1;\n"
//								+ "ALTER TABLE roletable auto_increment = 1;";
						//System.out.println("altering... =]");
						String alter1 = "ALTER TABLE departmenttable auto_increment = 1;";
						theModel.getDB().updateByQuery(alter1);
						String alter2 = "ALTER TABLE employeetable auto_increment = 1;";
						theModel.getDB().updateByQuery(alter2);
						String alter3 = "ALTER TABLE roletable auto_increment = 1;";
						theModel.getDB().updateByQuery(alter3);
					}
					theModel.getDB().setCompanyData(theModel.getCompany());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			//	Company tempComp = new Company(theModel.getCompany().getCompanyName());
				
			
				theView.getInsertEntStage().close();
			}

		};
		
		EventHandler<ActionEvent> showDeletionWindowHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if (theModel.getCompany() != null) {
					view.showDeletionWindow(theModel.getCompany());
					if (theView.getEntitiesForDeleteArray().size() > 0)
						view.addEventToRemoveNowButton(removeNowButtonHandler);
				} else {
					view.alertCompanyNull("change department preference.");
				}
			}

		};
	//	view.addEventToShowChangeDepPref(showDeletionWindowHandler);
		view.addEventToShowDeletionWindowHandler(showDeletionWindowHandler);

		EventHandler<ActionEvent> showChangeDepPref = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if (theModel.getCompany() != null) {
					view.showChangeDepPref(theModel.getCompany());
					if (theView.getDepPrefArray().size() > 0)
						view.addEventToNextStepButtonDepPref(nextStepDepPrefHandler);
				} else {
					view.alertCompanyNull("change department preference.");
				}
			}

		};
		view.addEventToShowChangeDepPref(showChangeDepPref);
		EventHandler<ActionEvent> showChangeRolePref = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if (theModel.getCompany() != null) {
					view.showChangeRolePref(theModel.getCompany());
					if (theView.getRolePrefArray().size() > 0)
						view.addEventToNextStepButtonRolePref(nextStepRolePrefHandler);
				} else {
					view.alertCompanyNull("change role preference.");

				}
			}

		};
		view.addEventToShowChangeRolePref(showChangeRolePref);

		EventHandler<ActionEvent> showResultsHandler = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				if (theModel.getCompany() == null) {
					view.alertCompanyNull("show experiment results.");
					return;
				}
				int result = getWinOrLoss();
				if (result > 0)
					view.showProfit(result);
				else if (result < 0){
					view.showLoss(result);
				}
				else {
					view.showNoChange();
				}

			}

		};
		view.addEventToShowExperimentResults(showResultsHandler);

	}

	public void sendCompanyData(String cmpName) {
		if (theModel.createCompany(cmpName)) {
		}

	}

	public void sendDepartmentData(String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		if (theModel.createDepartment(pref, changeable, synchronizable, hourDelta))
			;

	}

	public void sendRoleData(String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		if (theModel.createRole(pref, changeable, synchronizable, hourDelta))
			;

	}

	public void sendEmployeeData(String pref, int hourDelta, String employeeType, int baseSalary, int sales,
			int hourly) throws SQLException {
		if (theModel.createEmployee(pref, hourDelta, employeeType, baseSalary, sales, hourly))
			;

	}

	public void updateDepData(int depIndex, String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		theModel.updateDepData(depIndex, pref, changeable, synchronizable, hourDelta);
		theView.alertEditedSuccessfuly();
		theView.getInsertEntStage().close();
	}

	public void updateRoleData(int depIndex, String pref, boolean changeable, boolean synchronizable, int hourDelta,
			int roleIndex) throws SQLException {
		theModel.updateRoleData(depIndex, pref, changeable, synchronizable, hourDelta, roleIndex);
		theView.alertEditedSuccessfuly();
		theView.getInsertEntStage().close();
	}

	public int getWinOrLoss() {
		return theModel.getCompany().calcEfficieny();
	}

}
