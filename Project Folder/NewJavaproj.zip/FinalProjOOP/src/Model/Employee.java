package Model;

import java.io.Serializable;

public abstract class Employee implements Changeable, Serializable {
	private ePreferences myPreference;
	private int hourDelta;
	private boolean workFromHome = false;
	public static int empSerial = 1;
	private int empNum;
	private int EmpID;
	
	
	public Employee(ePreferences preference, int hourDeltaFromMvc) {
		setMyPreference(preference);
		setHourDelta(hourDeltaFromMvc);
		empNum = empSerial;
		empSerial++;
		
	}
	
	public Employee(ePreferences preference, int hourDeltaFromMvc , int id) {
		setMyPreference(preference);
		setHourDelta(hourDeltaFromMvc);
		empNum = empSerial;
		empSerial++;
		EmpID = id;
	}

	public void setMyPreference(ePreferences preference) {
		if (preference.equals(ePreferences.HOME)) {
			setWorkFromHome();
		}
		myPreference = preference;
	}

	public void setHourDelta(int hourDeltaFromMvc) {
		hourDelta = hourDeltaFromMvc;
	}

	public void minusEmpSerial() {
		empSerial--;
	}
	@Override

	public String toString() {
		String s;
		s = "Employee preference: " + myPreference + "\n EmpID: " + EmpID + "\n Hour delta: " + hourDelta + "\n";
		return s;
	}

	@Override
	public ePreferences getPreference() {
		return myPreference;
	}
	public int getHourDelta() {
		return hourDelta;
	}

	public void setWorkFromHome() {
		workFromHome = true;
	}
	
	public void setEmpID(int id) {
		EmpID = id;
	}
	
	public int getEmpID()
	{
		return empNum;
	}
	
	public int getEmpIDv2()
	{
		return EmpID;
	}


}
