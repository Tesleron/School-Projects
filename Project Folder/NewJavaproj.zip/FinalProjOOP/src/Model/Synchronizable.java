package Model;

public interface Synchronizable {
	public boolean isSynchonizable();
}
