package Model;

public interface Changeable {
	public ePreferences getPreference();
	public int getHourDelta();

}
