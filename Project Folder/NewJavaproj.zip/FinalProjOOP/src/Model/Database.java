package Model;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.sql.*;
import java.util.HashMap;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Database {
	private Connection conn;
	private String compName;

	public Database() throws ClassNotFoundException {
		conn = null;    
		createConnection();
	}

	public int selectByQueryDep (String query) throws SQLException { 
		int num = 0;
		ResultSet rs = conn.createStatement().executeQuery(query);
		while(rs.next()) {
			num = rs.getInt("DepID");
		}
		return num;
	}
	
	public int selectByQueryRole (String query) throws SQLException {        
		int num = 0;
		ResultSet rs = conn.createStatement().executeQuery(query);
		while(rs.next()) {
			num = rs.getInt("RoleID");
		}
		return num;
	}
	
	public int selectByQueryEmp (String query) throws SQLException {        
		int num = 0;
		ResultSet rs = conn.createStatement().executeQuery(query);
		while(rs.next()) {
			num = rs.getInt("EmpID");
		}
		return num;
	}

	public	void updateByQuery (String query) throws SQLException {
		int numAffectedRows = conn.createStatement().executeUpdate(query);
		System.out.printf("Num affected rows = %d\n",numAffectedRows);

	}




	public void createConnection() throws ClassNotFoundException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String dbUrl = "jdbc:mysql://localhost:3306/finalproject";

			conn = DriverManager.getConnection(dbUrl, "root", "a2de9kclwbf");
		}
		catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

	}

	public void setCompanyData(Company theCompany) throws SQLException {
		HashMap<Integer, Integer> roleDep = new HashMap<Integer, Integer>();
		int index = 0;
//		Department.depSerial = 1;
//		Role.roleSerial = 1;
//		Employee.empSerial = 1;
		
		ResultSet depResultSet = conn.createStatement().executeQuery("SELECT * FROM DepartmentTable");

		while (depResultSet.next()) {
			int DepID = (depResultSet.getInt("DepID"));
			String Preference = (depResultSet.getString("Preference"));
			String Synchronizable = (depResultSet.getString("Synchronizable"));
			String Changeable = (depResultSet.getString("Changeable"));
			int HourDelta = (depResultSet.getInt("HourDelta"));
			boolean isChangeable = Boolean.parseBoolean(Changeable);
			boolean isSynchronizable = Boolean.parseBoolean(Synchronizable);
			Department tempDep = new Department(isChangeable,ePreferences.valueOf(Preference),isSynchronizable,HourDelta,DepID);
			theCompany.addDepartment(tempDep);
		}
		ResultSet roleResultSet = conn.createStatement().executeQuery("SELECT * FROM RoleTable");

		while (roleResultSet.next()) {
			int RoleID = (roleResultSet.getInt("RoleID"));
			String Preference = (roleResultSet.getString("Preference"));
			String Synchronizable = (roleResultSet.getString("Synchronizable"));
			String Changeable = (roleResultSet.getString("Changeable"));
			int HourDelta = (roleResultSet.getInt("HourDelta"));
			int DepID = (roleResultSet.getInt("DepID"));
			index = theCompany.getIndexOfDepWithGivenID(theCompany.getAllDepartments(), DepID);

			boolean isChangeable = Boolean.parseBoolean(Changeable);
			boolean isSynchronizable = Boolean.parseBoolean(Synchronizable);

			roleDep.put(RoleID, DepID);
			

			Role tempRole = new Role(isChangeable,ePreferences.valueOf(Preference),isSynchronizable,HourDelta,RoleID);
			//index = theCompany.getIndexOfDepWithGivenID(theCompany.getAllDepartments(), DepID);
			theCompany.getAllDepartments().get(index).addRole(tempRole);
		}

		ResultSet employeeResultSet = conn.createStatement().executeQuery("SELECT * FROM EmployeeTable");

		while (employeeResultSet.next()) {
			int EmpID = (employeeResultSet.getInt("EmpID"));
			String Preference = (employeeResultSet.getString("Preference"));
			int HourDelta = (employeeResultSet.getInt("HourDelta"));
			int RoleID = (employeeResultSet.getInt("RoleID"));
			String type = (employeeResultSet.getString("empType"));
			int DepID = roleDep.get(RoleID); //Returns the specific department id
			
			index = theCompany.getIndexOfDepWithGivenID(theCompany.getAllDepartments(), DepID);
			int roleInd = theCompany.getAllDepartments().get(index).getIndexOfRoleWithGivenID(theCompany.getAllDepartments().get(index).getRoles(), RoleID);
			//System.out.println(RoleID + ", " + DepID);
			//System.out.println("Dep id:" + DepID+ " sits at index "+index+" in the arr.\nRole id :"+RoleID+" sits at index "+roleInd+" in the specific arr" );
			
			switch(type)
			{
			case "Base":
			{
				ResultSet baseEmployeeResultSet = conn.createStatement().executeQuery("SELECT * FROM BaseEmployeeTable WHERE EmpID = " + EmpID +";");
				while(baseEmployeeResultSet.next()) {
					int salary = baseEmployeeResultSet.getInt("Salary");
					BaseEmployee tempEmp = new BaseEmployee(HourDelta, salary,ePreferences.valueOf(Preference) , EmpID);
					
					theCompany.getAllDepartments().get(index).getRoles()
					.get(roleInd).addEmployeeToRole(tempEmp);
				}
				break;
			}

			case "Sales":
			{

				ResultSet salesEmployeeResultSet = conn.createStatement().executeQuery("SELECT * FROM BaseSalesEmployeeTable WHERE EmpID = " + EmpID +";");
				while(salesEmployeeResultSet.next()) {
					int salary = salesEmployeeResultSet.getInt("Salary");
					double salesPercentage = salesEmployeeResultSet.getInt("SalesPercentage");
					BaseAndSalesEmployee tempEmp = new BaseAndSalesEmployee(HourDelta, salary, salesPercentage, ePreferences.valueOf(Preference) , EmpID);
					//theCompany.getAllDepartments().get(DepID - 1).getRoles().get(RoleID -1).addEmployeeToRole(tempEmp);
					
//					theCompany.getAllDepartments().get(index).getRoles()
//					.get(theCompany.getAllDepartments().get(index)
//							.getIndexOfRoleWithGivenID(theCompany.getAllDepartments().get(index).getRoles(), RoleID)).addEmployeeToRole(tempEmp);
					
					theCompany.getAllDepartments().get(index).getRoles()
					.get(roleInd).addEmployeeToRole(tempEmp);
				}
				break;
			}

			case "Hourly":
			{
				ResultSet hourEmployeeResultSet = conn.createStatement().executeQuery("SELECT * FROM hourlyEmployeeTable WHERE EmpID = " + EmpID +";");
				while(hourEmployeeResultSet.next()) {
					int wage = hourEmployeeResultSet.getInt("Wage");
					HourlyEmployee tempEmp = new HourlyEmployee(HourDelta, wage,ePreferences.valueOf(Preference) , EmpID);
				//	theCompany.getAllDepartments().get(DepID - 1).getRoles().get(RoleID -1).addEmployeeToRole(tempEmp);
				
//					theCompany.getAllDepartments().get(index).getRoles()
//					.get(theCompany.getAllDepartments().get(index)
//							.getIndexOfRoleWithGivenID(theCompany.getAllDepartments().get(index).getRoles(), RoleID)).addEmployeeToRole(tempEmp);
					theCompany.getAllDepartments().get(index).getRoles()
					.get(roleInd).addEmployeeToRole(tempEmp);
				}
				break;
			}
			}


		}

		//alerts

		try {
			Alert a = new Alert(AlertType.NONE);
			a.setAlertType(AlertType.INFORMATION);
			a.setTitle("LOADING SUCCEED");
			a.setHeaderText("Company has been loaded from the database.");
			a.setContentText("You can use the menu.");
			a.show();	

		} catch (Exception err) {
			System.out.println(err.toString());
			Alert a = new Alert(AlertType.NONE);
			a.setAlertType(AlertType.INFORMATION);
			a.setTitle("LOADING FAILED");
			a.setHeaderText("Can not load company from database.");
			a.setContentText("Company will be started from scratch.");
			a.show();	
		}
	}




	public void closeConnection() throws SQLException {
		conn.close();
	}

	public Connection getConnection()
	{
		return conn;
	}

	public void setName(String name)
	{
		compName = name;
	}
}