package Model;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class Model {
	private Company currentCompany;
	private Database DB;

	public Model() throws ClassNotFoundException {
		DB = new Database();
	}

	public boolean createCompany(String name) {
		this.currentCompany = new Company(name);
		DB.setName(name);
		return true;
	}

	public boolean createDepartment(String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		if (!pref.equals("LATER") && !pref.equals("EARLIER"))
			hourDelta = 0;

		currentCompany.addDepartment(new Department(changeable, ePreferences.valueOf(pref), synchronizable, hourDelta));
				
		
		
		DB.updateByQuery("INSERT INTO DepartmentTable VALUES"
				+ " ( " + null +  ", '" + ePreferences.valueOf(pref)
				+ "', '" + synchronizable + "', '" + changeable + "', "
				+ hourDelta + " ); ");
		int depID = DB.selectByQueryDep("SELECT DepID FROM departmenttable ORDER BY DepID DESC LIMIT 1;");
		currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size()-1).setDepID(depID);
	//	System.out.println(DB.getConnection().getMetaData().getURL());

		//  DB.updateByQuery("(null,'LATER','Yes','No',3);");


		return true;
	}

	public boolean createRole(String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		if (!pref.equals("LATER") && !pref.equals("EARLIER"))
			hourDelta = 0;
		currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1)
		.addRole(new Role(changeable, ePreferences.valueOf(pref), synchronizable, hourDelta ));

		int depID = currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size()-1).getDepIDv2();
		System.out.println("depid is: " +depID);

		DB.updateByQuery("INSERT INTO RoleTable VALUES"
				+ " ( " + null +  ", '" + ePreferences.valueOf(pref)
				+ "', '" + synchronizable + "', '" + changeable + "', "
				+ hourDelta + ", " + depID + " ); ");
		int roleID = DB.selectByQueryRole("SELECT RoleID FROM roletable ORDER BY RoleID DESC LIMIT 1;\r\n"
				);
		currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size()-1).getRoles().get(currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size()-1).getRoles().size()-1).setRoleID(roleID);

		return true;
	}

	public boolean createEmployee(String pref,/* boolean changeable,*/ int hourDelta, String employeeType, int baseSalary,
			int hourly, int sales) throws SQLException {

		int roleID = currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1).getRoles()
				.get(currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1)
						.getRoles().size() - 1).getRoleID();
		int empID; 


		if (!pref.equals("LATER") && !pref.equals("EARLIER"))
			hourDelta = 0;

		if (employeeType.equals("BASE EMPLOYEE")) {

			BaseEmployee be = new BaseEmployee(hourDelta, baseSalary, ePreferences.valueOf(pref));
			//empID = be.getEmpIDv2();
			//System.out.println(empID);

			currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1).getRoles()
			.get(currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1)
					.getRoles().size() - 1)
			.addEmployeeToRole(be);


			//SQL//
			DB.updateByQuery("INSERT INTO EmployeeTable VALUES"
					+ " ( " + null +  ", '" + ePreferences.valueOf(pref)
					+ "', " + hourDelta + ", " + roleID + ",'Base');" );

			empID = DB.selectByQueryEmp("SELECT EmpID FROM employeetable ORDER BY EmpID DESC LIMIT 1;");

			DB.updateByQuery("INSERT INTO BaseEmployeeTable VALUES"
					+ " ( " + empID +  ", " + baseSalary + " ); ");

			be.setEmpID(empID);

		} else if (employeeType.equals("HOURLY EMPLOYEE")) {
			HourlyEmployee he = new HourlyEmployee(hourDelta, hourly, ePreferences.valueOf(pref));
//			empID = he.getEmpIDv2();
//			System.out.println(empID);

			currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1).getRoles()
			.get(currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1)
					.getRoles().size() - 1)
			.addEmployeeToRole(he);

			//SQL//

			DB.updateByQuery("INSERT INTO EmployeeTable VALUES"
					+ " ( " + null +  ", '" + ePreferences.valueOf(pref)
					+ "', " + hourDelta + ", " + roleID + ",'Hourly');");

			empID = DB.selectByQueryEmp("SELECT EmpID FROM employeetable ORDER BY EmpID DESC LIMIT 1;");

			DB.updateByQuery("INSERT INTO HourlyEmployeeTable VALUES"
					+ " ( " + empID +  ", " + hourly + " ); ");

			he.setEmpID(empID);
			
		} else {
			BaseAndSalesEmployee base = new BaseAndSalesEmployee(hourDelta, hourly, sales, ePreferences.valueOf(pref));
//			empID = base.getEmpIDv2();
//			System.out.println(empID);

			currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1).getRoles()
			.get(currentCompany.getAllDepartments().get(currentCompany.getAllDepartments().size() - 1)
					.getRoles().size() - 1)
			.addEmployeeToRole(base);


			//SQL//

			DB.updateByQuery("INSERT INTO EmployeeTable VALUES"
					+ " ( " + null +  ", '" + ePreferences.valueOf(pref)
					+ "', " + hourDelta + ", " + roleID + ",'Sales');");

			empID = DB.selectByQueryEmp("SELECT EmpID FROM employeetable ORDER BY EmpID DESC LIMIT 1;");

			DB.updateByQuery("INSERT INTO BaseSalesEmployeeTable VALUES"
					+ " ( " + empID +  ", " + baseSalary + ", " + sales/100 + " ); ");
			
			base.setEmpID(empID);
			
		}

		return true;
	}

	public void updateDepData(int depIndex, String pref, boolean changeable, boolean synchronizable, int hourDelta) throws SQLException {
		getCompany().getAllDepartments().get(depIndex).setDepPref(ePreferences.valueOf(pref));
		getCompany().getAllDepartments().get(depIndex).setIsChangeAble(changeable);
		getCompany().getAllDepartments().get(depIndex).setIsSynchronizable(synchronizable);
		getCompany().getAllDepartments().get(depIndex).setHourDelta(hourDelta);

		if (synchronizable == true) {
			updateEmpDataDep(depIndex, pref, hourDelta);
		}
		//add update query here
		DB.updateByQuery("UPDATE DepartmentTable"
				+ " SET Preference = '" + pref + "' " +", Synchronizable = '" + synchronizable +"' , Changeable = '" + changeable + "' , HourDelta = " +hourDelta
				+" WHERE DepID = " + (depIndex + 1) +";");

	}

	public void updateRoleData(int depIndex, String pref, boolean changeable, boolean synchronizable, int hourDelta,
			int roleIndex) throws SQLException {
		getCompany().getAllDepartments().get(depIndex).getRoles().get(roleIndex)
		.setRolePreference(ePreferences.valueOf(pref));
		getCompany().getAllDepartments().get(depIndex).getRoles().get(roleIndex).setIsChangeAble(changeable);
		getCompany().getAllDepartments().get(depIndex).getRoles().get(roleIndex).setIsSynchronizable(synchronizable);
		getCompany().getAllDepartments().get(depIndex).getRoles().get(roleIndex).setHourDelta(hourDelta);

		if (synchronizable == true) {
			updateEmpDataRole(depIndex, roleIndex, pref, hourDelta);
		}
		//add update query here
		int depID = getCompany().getAllDepartments().get(depIndex).getDepID();
		
		DB.updateByQuery("UPDATE RoleTable"
				+ " SET Preference = '" + pref + "' " +", Synchronizable = '" + synchronizable +"' , Changeable = '" + changeable + "' , HourDelta = " +hourDelta
				+" WHERE RoleID = " + (roleIndex + 1) +";");
		

	}

	public void updateEmpDataDep(int depIndex, String pref, int hourDelta) throws SQLException {
		for (int i = 0; i < currentCompany.getAllDepartments().get(depIndex).getRoles().size(); i++) {
			for (int j = 0; j < currentCompany.getAllDepartments().get(depIndex).getRoles().get(i).getEmployees()
					.size(); j++) {
				currentCompany.getAllDepartments().get(depIndex).getRoles().get(i).getEmployees().get(j)
				.setMyPreference(ePreferences.valueOf(pref));
				currentCompany.getAllDepartments().get(depIndex).getRoles().get(i).getEmployees().get(j)
				.setHourDelta(hourDelta);
				
				//SQL query to update employees according to department
//				
//				DB.updateByQuery("UPDATE EmployeeTable"
//						+ " SET Preference = '" + pref + "' " + "' , HourDelta = " +hourDelta
//						+" WHERE EmpID = " + (j + 1) +";");
//				
			}
		}

		//add update query here

	}

	public void updateEmpDataRole(int depIndex, int roleIndex, String pref, int hourDelta) throws SQLException {
		for (int i = 0; i < currentCompany.getAllDepartments().get(depIndex).getRoles().get(roleIndex).getEmployees()
				.size(); i++) {
			currentCompany.getAllDepartments().get(depIndex).getRoles().get(roleIndex).getEmployees().get(i)
			.setMyPreference(ePreferences.valueOf(pref));
			currentCompany.getAllDepartments().get(depIndex).getRoles().get(roleIndex).getEmployees().get(i)
			.setHourDelta(hourDelta);

		}
		int roleID = currentCompany.getAllDepartments().get(depIndex).getRoles().get(roleIndex).getRoleID();
		
		//SQL query to update the employees according to roles
		DB.updateByQuery("UPDATE EmployeeTable"
				+ " SET Preference = '" + pref + "' " + " , HourDelta = " +hourDelta
				+" WHERE RoleID = " + roleID +";");

		
	}
//	
//	public int findRoleByID(ArrayList<Department> arr) {
//		for(int i = 0; i < arr.size(); i++) {
//			if()
//		}
//	}

	public void loadCompany() throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {
    //    this.currentCompany = new ReadObject().readCompany();
        Company theCompany = new Company("The company");
        DB.setCompanyData(theCompany);
        
        this.currentCompany = theCompany;
        
     //  Department.depSerial--;
	}

	public void saveToFile() throws FileNotFoundException, IOException {
		WriteObject object = new WriteObject(currentCompany);
		//might not be needed anymore
		
	}

	// GETTERS

	public Company getCompany() {
		return currentCompany;
	}
	
	public Database getDB() {
		return DB;
	}

}
