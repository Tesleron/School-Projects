package Model;


public interface Preference {
	public int getPreference();
		
	
	
}
