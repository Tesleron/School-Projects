package Model;

public class BaseAndSalesEmployee extends Employee{
	private int monthlyPayment;
	private double salesPercentage;
	
	public BaseAndSalesEmployee(int hourDeltaFromMvc/*, Role role*/,int hourlyPayment,double salePrecentage,ePreferences preference) {
		super(preference,hourDeltaFromMvc);
		monthlyPayment = hourlyPayment;
		salesPercentage = salePrecentage;	
	}
	
	public BaseAndSalesEmployee(int hourDeltaFromMvc/*, Role role*/,int hourlyPayment,double salePrecentage,ePreferences preference,int id) {
		super(preference,hourDeltaFromMvc,id);
		monthlyPayment = hourlyPayment;
		salesPercentage = salePrecentage;	
	}
	
	public String toString() {
		return super.toString() + "Employee type:" + getClass().getSimpleName() + "\n Monthly payment:"
				+ monthlyPayment + " Sales Percentage: " + salesPercentage + "%";
	}
	
}
