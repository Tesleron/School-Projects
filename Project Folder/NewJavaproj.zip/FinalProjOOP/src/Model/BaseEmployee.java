package Model;

public class BaseEmployee extends Employee {
	private int salary;

	public BaseEmployee(int hourDeltaFromMvc, int hourlyPayment, ePreferences preference) {
		super(preference, hourDeltaFromMvc);
		salary = hourlyPayment;
	}
	
	public BaseEmployee(int hourDeltaFromMvc, int hourlyPayment, ePreferences preference,int id) {
		super(preference, hourDeltaFromMvc,id);
		salary = hourlyPayment;
	}

	public String toString() {
		return super.toString() + "Employee type:" + getClass().getSimpleName() + "\n Monthly payment:"
				+ salary;
	}

}
