package Model;

import java.io.Serializable;
import java.util.ArrayList;

public class Department implements Changeable, Synchronizable, Serializable {
//	public enum ePreferences {EARLIER,LATER,SAME,HOME};
	private ePreferences departmentPreference;
	private ArrayList<Role> Roles;
	private boolean isChangeAble;
	private boolean isSynchronizable;
	private int hourDelta;
	
	public static int depSerial = 1;
	private int depID;
	private int theDepID;

	public Department(boolean isChangeAble, ePreferences p, boolean isSynchronizable, int hourDelta) {
		Roles = new ArrayList<Role>();
		setDepPref(p);
		setIsChangeAble(isChangeAble);
		setHourDelta(hourDelta);
		setIsSynchronizable(isSynchronizable);
		
		depID = depSerial;
		depSerial++;
		
	}

	
	public Department(boolean isChangeAble, ePreferences p, boolean isSynchronizable, int hourDelta,int id) {
		Roles = new ArrayList<Role>();
		setDepPref(p);
		setIsChangeAble(isChangeAble);
		setHourDelta(hourDelta);
		setIsSynchronizable(isSynchronizable);
		
		depID = depSerial;
		depSerial++;
		theDepID = id;
	}

	public void setIsChangeAble(boolean isChangeAble) {
		this.isChangeAble = isChangeAble;
	}
	public void setHourDelta(int hourDelta) {
		this.hourDelta = hourDelta;
	}
	public void setIsSynchronizable(boolean isSynchronizable) {
		this.isSynchronizable = isSynchronizable;
	}
	public void setDepPref(ePreferences p) {
		departmentPreference = p;
	}
	
	public void setDepID(int id) {
		theDepID = id;
	}

	public ArrayList<Role> getRoles() {
		return Roles;
	}

	@Override

	public String toString() {
		String s;
		s = "DepID: "+theDepID+"\nDepartment preference: " + departmentPreference + "\n isSynchronizable: " + isSynchronizable
				+ "\n isChangeAble: " + isChangeAble + "\n Hour delta: " + hourDelta
				+ "\n Role list in department: \n\n";
		for (int i = 0; i < Roles.size(); i++) {
			s += (i + 1) + ")" + Roles.get(i).toString() + "\n";
		}
		return s;
	}

	public void addRole(Role r) {
		Roles.add(r);
	}
	public void minusDepSerial() {
		depSerial--;
	}

	@Override
	public ePreferences getPreference() {
		return departmentPreference;
	}

	@Override
	public int getHourDelta() {
		return hourDelta;
	}
	@Override
	public boolean isSynchonizable() {
		return isSynchronizable;
	}
	
	public boolean getIsChangeAble() {
		return isChangeAble;
	}
	
	public int getDepID()
	{
		return depID;
	}
	
	public int getDepIDv2()
	{
		return theDepID;
	}
	
	public int getIndexOfRoleWithGivenID(ArrayList<Role> Roles , int RoleID)
	{
		for (int i = 0; i < Roles.size(); i++) {
			if(Roles.get(i).getRoleID() == RoleID)
				return i;
		}
		return -1;
		
	}

}
